# शुभ विवाह — Royal Rajasthani Wedding Invitation

A responsive, Hindi-first Hindu wedding invitation experience built with **React, Vite, Tailwind CSS v4, Three.js, and React Three Fiber**. The site includes a procedural 3D haveli entrance, a Ganesh-first opening screen with a golden aura effect, a dedicated `/ganesh` vandana page, ceremony pages, wedding countdown, story timeline, venue, gallery, sharing, demo ambience, RSVP, and a Hindi admin panel for couple photos, Ganesh artwork and custom routes.

> The couple's names, date, venue, and other personal information are intentionally blank. Update them in `src/data/weddingData.js` before publishing.

## Run locally

Use Node.js 20.19+ or 22.12+.

```bash
npm install
npm run dev
```

Open the local URL shown by Vite (usually `http://localhost:5173`). To test a production build:

```bash
npm run build
npm run preview
```

## Admin panel and custom pages

Open `/admin` while the project is running. The local demo PIN is `SHAADI2026`. Use **विवरण व फ़ोटो** to change bride/groom names and photos, optionally upload a replacement Ganesh Ji image, and update the date and venue. Use **पृष्ठ प्रबंधक** to create, edit, hide from navigation, preview, or delete custom wedding pages; each page receives its own route, such as `/mehndi`, `/haldi`, or `/sangeet`. The built-in routes are `/ganesh`, `/events`, `/story`, `/venue`, `/gallery`, and `/rsvp`.

**Admin persistence/security note:** this starter is a local demo. Its PIN check is client-side and its configuration, uploaded image data, custom pages and RSVP responses are stored in the current browser's `localStorage`; edits do not sync to guests on other devices and this is not production authentication. For a public wedding site, add server-side authentication plus a database and image storage service.

## Personalize the invitation

Edit `src/data/weddingData.js`:

- `brideName`, `groomName`, and `familyLine`
- Optional `ganeshPhoto` override; by default the invitation uses `public/images/ganesh-ji-royal.jpg`
- `weddingDate` in ISO format, including timezone (example: `2027-02-14T18:30:00+05:30`)
- `weddingDateLabel`, `weddingTimeLabel`
- `venue.name`, `venue.address`, `venue.city`, `venue.googleMapsQuery`
- ceremony details in `events`
- relationship milestones in `story`
- `musicUrl` if you have a licensed shehnai or instrumental file

The devotional art at `public/images/ganesh-ji-royal.jpg` is the supplied default; the admin panel can override it with a compressed upload. The demo audio at `public/music/ambient-drone.wav` is a small, original synthesized background ambience. It is not a traditional instrument recording. Replace it with audio you have permission to use if desired. Playback begins only after the visitor presses the music control.

## What currently works

- Ganesh Ji is the first thing guests see: devotional artwork, glowing golden frame, gentle aura/petal accents and the ‘श्री गणेशाय नमः’ blessing before opening the invitation
- Dedicated `/ganesh` vandana route
- Admin demo login (`/admin`, PIN `SHAADI2026`) with bride/groom/Ganesh image uploads, wedding detail editing and custom page/route management
- Custom page routes such as `/mehndi` can be created and managed in the admin page
- Opening-screen transition and responsive navigation menu
- 3D Rajasthani haveli / mandap-inspired scene with lighting, slow parallax, floating petals, and diyas
- Live countdown after a wedding date is configured
- Expandable ceremony cards
- Story timeline
- Web Share API / clipboard fallback
- Venue directions button after a real address or Maps URL is configured
- RSVP form validation, attendance selection, guest count and message
- RSVP demo submissions stored in **that visitor's current browser only** using localStorage
- Background audio play/pause

## Important before sending to guests

The RSVP form is a frontend demo. `localStorage` does **not** send responses to the hosts and does not synchronize guest submissions across devices. To collect real RSVPs, connect the form to a backend/API and database, or to a form service. Add privacy and retention details as appropriate. Configure the real names, date, venue, event schedule and an actual map link before publishing.

## Deploy to Vercel

1. Push the project to a Git repository.
2. Import that repository in Vercel.
3. Use the default Vite build settings: build command `npm run build`, output directory `dist`.
4. Redeploy after updating `weddingData.js`.

## Folder overview

```text
src/
  components/PalaceScene.jsx       Procedural 3D scene (no external model needed)
  data/weddingData.js              Default wedding details
  lib/weddingSettings.js           Local demo settings + custom page storage
  pages/AdminPage.jsx              Demo admin, photo upload and custom page manager
  pages/InvitationPages.jsx        Fixed and custom route page layouts
  App.jsx                           Main invitation and router
  index.css                         Responsive visual design
  main.jsx                          React entry point
public/
  images/ganesh-ji-royal.jpg        Default Ganesh Ji devotional artwork
  music/ambient-drone.wav           Demo ambience
```


## Updated Ganesh garden cover and countdown

- The opening overlay now uses `public/images/ganesh-garden-hero.jpg`, a clean, wide Rajasthani garden scene created from the look of the supplied reference.
- `public/images/ganesh-garden-reference-crop.jpg` contains the cropped upper photograph from the supplied reference for comparison/reference.
- The opening garden scene, standalone Lord Ganesha portrait, bride portrait and groom portrait are separate assets and can be changed separately in `/admin` → **दूल्हा और दुल्हन**.
- To start the live countdown, open `/admin`, enter the wedding date and exact time in the **Countdown की तारीख और समय** field, then select **बदलाव सुरक्षित करें**. The countdown refreshes every second and uses India Standard Time (+05:30). No wedding date was supplied, so no date has been invented.
- RSVP responses and image changes still use this browser's local storage in demo mode; connect a backend/database and persistent image storage before publishing for shared guest/admin access.

### श्री गणेश वंदना ऑडियो और लाइव लिरिक्स

`/ganesh` पेज पर `public/music/ganesh-mantra.mp3` का भक्तिमय ऑडियो प्लेयर है। रिकॉर्डिंग के शुरुआती लगभग 18 सेकंड के संगीत-इंट्रो को हटाकर वेब के लिए 160 kbps में ऑप्टिमाइज़ किया गया है। खिलाड़ी में play/pause, 10 सेकंड पीछे/आगे, seek bar, volume, क्लिक-टू-seek Sanskrit पंक्तियाँ, लाइव हाइलाइट और स्क्रॉल करने योग्य शब्दार्थ शामिल हैं।

यदि ऑडियो रिकॉर्डिंग बदलें, तो `src/components/GaneshMantraPlayer.jsx` में `LYRICS` के `start` और `end` सेकंड को नए ऑडियो के अनुसार समायोजित करें। वेबसाइट पर सामग्री/ऑडियो चलाने से पहले रिकॉर्डिंग के उपयोग के अधिकार सुनिश्चित करें।


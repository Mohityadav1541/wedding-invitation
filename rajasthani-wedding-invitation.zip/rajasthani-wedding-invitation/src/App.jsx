import { useEffect, useMemo, useRef, useState } from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import {
  ArrowDown, ArrowUpRight, CalendarDays, Check, ChevronDown, Clock3, Copy,
  Flower2, Heart, MapPin, Menu, Music2, Pause, Play, Send, Share2, Sparkles,
  Sun, Users, X, Flame, MapPinned,
} from 'lucide-react'
import PalaceScene from './components/PalaceScene.jsx'
import AdminPage from './pages/AdminPage.jsx'
import { CustomWeddingPage, FixedInvitationPage } from './pages/InvitationPages.jsx'
import { useCustomPages, useWeddingData } from './lib/weddingSettings.js'

const navItems = [
  ['/ganesh', 'श्री गणेश वंदना'],
  ['#invite', 'आमंत्रण'],
  ['#celebrations', 'शुभ अवसर'],
  ['#our-story', 'हमारी कहानी'],
  ['#venue', 'शुभ स्थल'],
]

const iconMap = {
  flower: Flower2,
  sun: Sun,
  music: Music2,
  sparkles: Sparkles,
  heart: Heart,
}

function Ornament({ className = '' }) {
  return (
    <div className={`ornament ${className}`} aria-hidden="true">
      <span />
      <Flower2 size={19} strokeWidth={1.2} />
      <span />
    </div>
  )
}

function Reveal({ children, className = '', delay = 0 }) {
  const ref = useRef(null)
  useEffect(() => {
    const element = ref.current
    if (!element) return
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        element.classList.add('is-visible')
        observer.unobserve(element)
      }
    }, { threshold: 0.1, rootMargin: '0px 0px -30px 0px' })
    observer.observe(element)
    return () => observer.disconnect()
  }, [])
  return <div ref={ref} className={`reveal ${className}`} style={{ '--reveal-delay': `${delay}ms` }}>{children}</div>
}

function Countdown({ weddingDate }) {
  const [now, setNow] = useState(() => Date.now())
  const target = weddingDate ? new Date(weddingDate).getTime() : Number.NaN
  const targetIsValid = Number.isFinite(target)

  useEffect(() => {
    if (!targetIsValid || target <= Date.now()) return
    const timer = window.setInterval(() => {
      const currentTime = Date.now()
      setNow(currentTime)
      if (currentTime >= target) window.clearInterval(timer)
    }, 1000)
    return () => window.clearInterval(timer)
  }, [target, targetIsValid])

  const remaining = targetIsValid ? target - now : null
  const parts = remaining !== null && remaining > 0 ? [
    ['दिन', Math.floor(remaining / 86400000)],
    ['घंटे', Math.floor((remaining % 86400000) / 3600000)],
    ['मिनट', Math.floor((remaining % 3600000) / 60000)],
    ['सेकंड', Math.floor((remaining % 60000) / 1000)],
  ] : null

  return (
    <div className="countdown-wrap">
      <div className="countdown-label"><span className="tiny-sun">✳</span> मंगल घड़ी की प्रतीक्षा <span className="tiny-sun">✳</span></div>
      {parts ? (
        <div className="countdown-grid" aria-live="polite">
          {parts.map(([label, value]) => (
            <div className="countdown-cell" key={label}>
              <span className="countdown-number">{String(value).padStart(2, '0')}</span>
              <span className="countdown-unit">{label}</span>
            </div>
          ))}
        </div>
      ) : targetIsValid ? (
        <div className="countdown-awaiting countdown-complete"><span>✦</span><span>{remaining > -86400000 ? 'शुभ विवाह की मंगल घड़ी आ चुकी है' : 'शुभ विवाह संपन्न हो चुका है'}</span><span>✦</span></div>
      ) : (
        <div className="countdown-awaiting"><span>—</span><span>व्यवस्थापक पृष्ठ पर विवाह की तारीख और समय जोड़ें</span><span>—</span></div>
      )}
    </div>
  )
}

function CeremonyCard({ event, index, venueName }) {
  const Icon = iconMap[event.icon] || Sparkles
  const [expanded, setExpanded] = useState(false)
  return (
    <Reveal className="ceremony-card-reveal" delay={index * 90}>
      <article className={`ceremony-card ceremony-card-${index + 1} ${expanded ? 'expanded' : ''}`}>
        <div className="ceremony-topline"><span>०{index + 1}</span><span className="ceremony-icon"><Icon size={22} strokeWidth={1.45} /></span></div>
        <div className="ceremony-title-wrap">
          <p className="ceremony-subtitle">{event.subtitle}</p>
          <h3>{event.title}</h3>
        </div>
        <div className="ceremony-meta">
          <div><CalendarDays size={15} /><span>{event.date || 'तिथि शीघ्र घोषित होगी'}</span></div>
          <div><Clock3 size={15} /><span>{event.time || 'समय जल्द साझा किया जाएगा'}</span></div>
        </div>
        <p className="ceremony-description">{event.description}</p>
        {expanded && (
          <div className="ceremony-extra">
            <span className="mini-label">वेशभूषा</span>
            <p>{event.attire || 'पारंपरिक परिधान'}</p>
            <span className="mini-label">स्थान</span>
            <p>{venueName || 'विवरण शीघ्र उपलब्ध होगा'}</p>
          </div>
        )}
        <button className="text-action ceremony-more" type="button" onClick={() => setExpanded((value) => !value)} aria-expanded={expanded}>
          {expanded ? 'कम देखें' : 'और जानें'} <ChevronDown size={15} className={expanded ? 'rotate-up' : ''} />
        </button>
        <div className="card-corner" aria-hidden="true">✦</div>
      </article>
    </Reveal>
  )
}

function Toast({ toast }) {
  if (!toast) return null
  return <div className="toast" role="status"><span className="toast-icon"><Check size={17} /></span><span>{toast}</span></div>
}

export function WeddingHome() {
  const weddingData = useWeddingData()
  const customPages = useCustomPages()
  const [introVisible, setIntroVisible] = useState(true)
  const [introLeaving, setIntroLeaving] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [musicPlaying, setMusicPlaying] = useState(false)
  const [toast, setToast] = useState('')
  const [rsvpSent, setRsvpSent] = useState(false)
  const [rsvp, setRsvp] = useState({ name: '', phone: '', attendance: 'yes', guests: '2', message: '' })
  const [showAllStory, setShowAllStory] = useState(false)
  const audioRef = useRef(null)
  const toastTimer = useRef(null)

  const fullNames = useMemo(() => {
    const bride = weddingData.brideName.trim() || 'दुल्हन का नाम'
    const groom = weddingData.groomName.trim() || 'दूल्हे का नाम'
    return { bride, groom }
  }, [weddingData.brideName, weddingData.groomName])

  const showToast = (message) => {
    setToast(message)
    window.clearTimeout(toastTimer.current)
    toastTimer.current = window.setTimeout(() => setToast(''), 3600)
  }

  useEffect(() => () => window.clearTimeout(toastTimer.current), [])

  const openInvitation = () => {
    setIntroLeaving(true)
    window.setTimeout(() => setIntroVisible(false), 750)
  }

  const toggleMusic = async () => {
    const audio = audioRef.current
    if (!audio) return
    if (musicPlaying) {
      audio.pause()
      setMusicPlaying(false)
      showToast('संगीत विराम पर है')
      return
    }
    try {
      await audio.play()
      setMusicPlaying(true)
      showToast('मंगल धुन शुरू हो गई है')
    } catch {
      showToast('संगीत चलाने के लिए कृपया दोबारा स्पर्श करें')
    }
  }

  const shareInvitation = async () => {
    const shareData = {
      title: 'शुभ विवाह — शाही आमंत्रण',
      text: `${fullNames.bride} एवं ${fullNames.groom} के शुभ विवाह में सादर आमंत्रित हैं।`,
      url: window.location.href,
    }
    try {
      if (navigator.share) {
        await navigator.share(shareData)
      } else if (navigator.clipboard?.writeText) {
        await navigator.clipboard.writeText(`${shareData.text}\n${shareData.url}`)
        showToast('आमंत्रण का लिंक कॉपी हो गया है')
      } else {
        showToast('इस पेज का लिंक कॉपी करके मेहमानों से साझा करें')
      }
    } catch (error) {
      if (error?.name !== 'AbortError') showToast('लिंक साझा नहीं हो पाया; कृपया URL कॉपी करें')
    }
  }

  const openMap = () => {
    const query = weddingData.venue.googleMapsQuery || weddingData.venue.address || weddingData.venue.name
    if (!query) {
      showToast('मानचित्र जोड़ने के लिए weddingData.js में स्थल का पता भरें')
      return
    }
    const isUrl = /^https?:\/\//i.test(query)
    window.open(isUrl ? query : `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(query)}`, '_blank', 'noopener,noreferrer')
  }

  const handleRsvp = (event) => {
    event.preventDefault()
    if (!rsvp.name.trim()) {
      showToast('कृपया अपना नाम लिखें')
      return
    }
    const record = {
      ...rsvp,
      name: rsvp.name.trim(),
      submittedAt: new Date().toISOString(),
      couple: fullNames,
    }
    try {
      const existing = JSON.parse(window.localStorage.getItem('rajasthani-wedding-rsvp') || '[]')
      window.localStorage.setItem('rajasthani-wedding-rsvp', JSON.stringify([...existing, record]))
    } catch {
      // The form still shows confirmation if browser storage is unavailable.
    }
    setRsvpSent(true)
    showToast('आपका उत्तर इसी ब्राउज़र में सुरक्षित हुआ है')
  }

  const resetRsvp = () => {
    setRsvp({ name: '', phone: '', attendance: 'yes', guests: '2', message: '' })
    setRsvpSent(false)
  }

  const storyItems = showAllStory ? weddingData.story : weddingData.story.slice(0, 2)

  return (
    <div className="site-shell min-h-screen">
      <audio ref={audioRef} src={weddingData.musicUrl || undefined} loop preload="none" />
      <div className="top-ribbon"><span>॥ श्री गणेशाय नमः ॥</span><span className="top-ribbon-center">एक पावन बंधन · दो परिवार · अनगिनत आशीर्वाद</span><span>॥ शुभ मंगलम् ॥</span></div>

      <header className="site-header">
        <a className="brand" href="#top" aria-label="मुखपृष्ठ पर जाएँ">
          <span className="brand-mark"><span>श्री</span><i /></span>
          <span className="brand-words"><strong>शुभ विवाह</strong><small>एक शाही आमंत्रण</small></span>
        </a>
        <nav className={`desktop-nav ${mobileMenuOpen ? 'nav-open' : ''}`} aria-label="मुख्य नेविगेशन">
          {navItems.map(([href, label]) => <a key={href} href={href} onClick={() => setMobileMenuOpen(false)}>{label}</a>)}
          {customPages.filter((page) => page.showInNav !== false).map((page) => <a key={page.id} href={`/${page.slug}`} onClick={() => setMobileMenuOpen(false)}>{page.title}</a>)}
          <a className="nav-rsvp" href="#rsvp" onClick={() => setMobileMenuOpen(false)}>अपनी उपस्थिति बताएँ <ArrowUpRight size={15} /></a>
        </nav>
        <div className="header-actions">
          <button type="button" className={`music-button ${musicPlaying ? 'is-playing' : ''}`} onClick={toggleMusic} aria-label={musicPlaying ? 'संगीत रोकें' : 'मंगल धुन चलाएँ'}>
            {musicPlaying ? <Pause size={16} /> : <Play size={16} />}<span>{musicPlaying ? 'धुन चल रही है' : 'मंगल धुन'}</span><i className="sound-bars"><b /><b /><b /></i>
          </button>
          <button type="button" className="mobile-menu-button" onClick={() => setMobileMenuOpen((v) => !v)} aria-label={mobileMenuOpen ? 'मेनू बंद करें' : 'मेनू खोलें'}>
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </header>

      <main id="top">
        <section className="hero-section" id="invite">
          <div className="hero-texture" aria-hidden="true" />
          <div className="hero-copy">
            <Reveal>
              <div className="eyebrow"><span className="eyebrow-line" /> सप्रेम आमंत्रण <span className="eyebrow-line" /></div>
              <div className="ganesh-stamp" aria-hidden="true"><span>ॐ</span><small>श्री गणेशाय नमः</small></div>
              <h1>दो दिलों का<br /><em>एक पावन</em><br />बंधन</h1>
              <p className="hero-intro">ईश्वर की असीम कृपा और बड़ों के आशीर्वाद से<br className="desktop-break" /> हमारे जीवन का नया अध्याय आरंभ होने जा रहा है।</p>
              <div className="couple-names"><span>{fullNames.bride}</span><i>और</i><span>{fullNames.groom}</span></div>
              <div className="hero-couple-portraits">
                <div className="hero-person-portrait">{weddingData.bridePhoto ? <img src={weddingData.bridePhoto} alt={fullNames.bride} /> : <span>दु</span>}<small>दुल्हन</small></div>
                <span className="portrait-heart">♥</span>
                <div className="hero-person-portrait">{weddingData.groomPhoto ? <img src={weddingData.groomPhoto} alt={fullNames.groom} /> : <span>दू</span>}<small>दूल्हा</small></div>
              </div>
              <p className="family-line">{weddingData.familyLine}</p>
              <Ornament className="hero-ornament" />
              <div className="hero-date">
                <CalendarDays size={17} strokeWidth={1.4} />
                <span>{weddingData.weddingDateLabel || 'शुभ तिथि शीघ्र घोषित होगी'}</span>
                <span className="date-dot">✦</span>
                <span>{weddingData.weddingTimeLabel || 'शुभ मुहूर्त'}</span>
              </div>
              <div className="hero-cta-row">
                <a className="button button-gold" href="#celebrations">विवाह उत्सव देखें <ArrowDown size={16} /></a>
                <button type="button" className="button button-quiet" onClick={shareInvitation}><Share2 size={16} /> आमंत्रण साझा करें</button>
              </div>
            </Reveal>
          </div>
          <div className="hero-art-wrap">
            <div className="hero-art-glow" />
            <div className="art-label art-label-top"><span>राजसी</span><span>✦</span><span>परंपरा</span></div>
            <PalaceScene />
            <div className="art-caption"><span /> राजस्थान की शाही विरासत <span /></div>
            <div className="hero-side-seal" aria-hidden="true"><span>मंगलम्</span><b>✺</b><span>सु-विवाह</span></div>
          </div>
          <div className="hero-bottom-note"><span>०१</span><span>आशीर्वाद • आनंद • अनंत साथ</span><a href="#countdown" aria-label="आगे बढ़ें"><ArrowDown size={17} /></a></div>
        </section>

        <section className="blessing-section section-pad" aria-labelledby="blessing-title">
          <Reveal className="blessing-inner">
            <div className="blessing-emblem"><span>ॐ</span><i /></div>
            <p className="section-kicker">मंगलम भगवान विष्णुः</p>
            <h2 id="blessing-title">शुभारंभ शुभ आशीषों के साथ</h2>
            <div className="sanskrit-blessing">{weddingData.blessing.split('\n').map((line) => <span key={line}>{line}</span>)}</div>
            <Ornament />
            <p className="blessing-note">आपकी उपस्थिति इस पावन अवसर को और भी मंगलमय बनाएगी।</p>
          </Reveal>
        </section>

        <section className="countdown-section section-pad" id="countdown">
          <div className="countdown-pattern" aria-hidden="true" />
          <Reveal className="countdown-content">
            <p className="section-kicker light-kicker">वह शुभ घड़ी</p>
            <h2>जब दो जीवन एक राह चुनेंगे</h2>
            <Countdown weddingDate={weddingData.weddingDate} />
            <p className="countdown-footnote">{weddingData.weddingDate ? `उलटी गिनती निर्धारित शुभ मुहूर्त तक हर सेकंड अपडेट होती है। ${weddingData.weddingTimeLabel || ''}` : 'व्यवस्थापक पृष्ठ पर तारीख और समय सहेजते ही उलटी गिनती शुरू हो जाएगी।'}</p>
          </Reveal>
        </section>

        <section className="celebrations-section section-pad" id="celebrations">
          <div className="section-heading">
            <Reveal>
              <p className="section-kicker">उत्सवों की रौनक</p>
              <h2>हर रस्म में <em>एक कहानी</em></h2>
              <p className="section-description">रीति-रिवाज़, संगीत और अपनों का स्नेह — आइए, इन यादगार पलों के साक्षी बनें।</p>
            </Reveal>
            <Reveal delay={120}><span className="heading-seal">शुभ<br />लाभ</span></Reveal>
          </div>
          <div className="ceremony-grid">
            {weddingData.events.map((event, index) => <CeremonyCard key={event.id} event={event} index={index} venueName={weddingData.venue.name} />)}
          </div>
          <p className="events-note"><Sparkles size={15} /> सभी तिथियाँ, समय और कार्यक्रम वास्तविक विवरण जोड़ने के बाद अपडेट किए जा सकते हैं।</p>
        </section>

        <section className="story-section section-pad" id="our-story">
          <div className="story-architecture" aria-hidden="true"><div className="story-arch" /><div className="story-arch inner" /><div className="story-lotus">✿</div></div>
          <Reveal className="story-intro">
            <p className="section-kicker light-kicker">एक रिश्ता · एक सफ़र</p>
            <h2>हमारी कहानी,<br /><em>हमारे अपनों के नाम</em></h2>
            <p>कुछ रिश्ते संयोग से मिलते हैं, और आशीर्वाद से जीवनभर का साथ बन जाते हैं।</p>
          </Reveal>
          <div className="story-timeline">
            {storyItems.map((item, index) => (
              <Reveal key={item.title} className={`story-item story-item-${index + 1}`} delay={index * 100}>
                <span className="story-dot"><Heart size={14} fill="currentColor" /></span>
                <div className="story-card"><span className="story-year">{item.year}</span><h3>{item.title}</h3><p>{item.description}</p></div>
              </Reveal>
            ))}
          </div>
          {weddingData.story.length > 2 && <button className="story-expand" type="button" onClick={() => setShowAllStory((v) => !v)}>{showAllStory ? 'कम यादें देखें' : 'पूरी कहानी पढ़ें'} <ChevronDown size={16} className={showAllStory ? 'rotate-up' : ''} /></button>}
        </section>

        <section className="venue-section section-pad" id="venue">
          <Reveal className="venue-card">
            <div className="venue-copy">
              <p className="section-kicker">मिलन का शुभ स्थल</p>
              <h2>आपकी प्रतीक्षा में<br /><em>हमारा आँगन</em></h2>
              <p className="venue-intro">आपके स्नेह और आशीर्वाद से ही यह उत्सव पूर्ण होगा। स्थल का पूरा विवरण जल्द साझा किया जाएगा।</p>
              <div className="venue-detail"><MapPin size={18} /><div><strong>{weddingData.venue.name || 'विवाह स्थल का नाम'}</strong><span>{weddingData.venue.address || weddingData.venue.city || 'पता शीघ्र घोषित होगा'}</span></div></div>
              <div className="venue-detail"><CalendarDays size={18} /><div><strong>{weddingData.weddingDateLabel || 'शुभ तिथि शीघ्र घोषित होगी'}</strong><span>{weddingData.weddingTimeLabel || 'मुहूर्त की जानकारी जल्द मिलेगी'}</span></div></div>
              <button className="button button-maroon" type="button" onClick={openMap}>मानचित्र में देखें <MapPinned size={16} /></button>
            </div>
            <div className="venue-art" aria-label="राजस्थानी हवेली से प्रेरित सजावटी चित्र">
              <div className="venue-sky"><span className="venue-moon" /></div>
              <div className="venue-palace">
                <div className="venue-tower tower-left"><i /><b /><span /></div>
                <div className="venue-wing wing-left"><i /><i /><i /></div>
                <div className="venue-center"><div className="venue-center-dome" /><div className="venue-door"><span /></div><div className="venue-balcony" /></div>
                <div className="venue-wing wing-right"><i /><i /><i /></div>
                <div className="venue-tower tower-right"><i /><b /><span /></div>
              </div>
              <div className="venue-ground"><span>✦</span><span>✿</span><span>✦</span></div>
              <p className="venue-art-caption">पधारो म्हारे देश</p>
            </div>
          </Reveal>
        </section>

        <section className="rsvp-section section-pad" id="rsvp">
          <div className="rsvp-pattern" aria-hidden="true" />
          <div className="rsvp-layout">
            <Reveal className="rsvp-copy">
              <div className="rsvp-emblem"><Users size={26} strokeWidth={1.2} /></div>
              <p className="section-kicker light-kicker">आपका स्नेह अनमोल है</p>
              <h2>क्या आप<br /><em>पधार रहे हैं?</em></h2>
              <p>कृपया अपनी उपस्थिति की जानकारी दें, ताकि हम आपके स्वागत की तैयारी प्रेमपूर्वक कर सकें।</p>
              <Ornament />
              <p className="rsvp-family-note">सप्रेम प्रतीक्षारत,<br /><strong>दोनों परिवार</strong></p>
            </Reveal>
            <Reveal className="rsvp-form-wrap" delay={130}>
              {rsvpSent ? (
                <div className="rsvp-success">
                  <div className="success-stamp"><Check size={30} /></div>
                  <p className="section-kicker">धन्यवाद</p>
                  <h3>आपके स्नेह के लिए आभार!</h3>
                  <p>आपका उत्तर इस ब्राउज़र में सुरक्षित हुआ है। वास्तविक मेहमानों की सूची के लिए सर्वर से जोड़ना आवश्यक होगा।</p>
                  <button className="button button-gold" type="button" onClick={resetRsvp}>एक और उत्तर भेजें</button>
                </div>
              ) : (
                <form className="rsvp-form" onSubmit={handleRsvp}>
                  <div className="form-title"><span className="mini-label">उपस्थिति-पत्र</span><h3>अपना उत्तर दें</h3><p>तारांकित जानकारी आवश्यक है।</p></div>
                  <label className="field-label">आपका पूरा नाम <span>*</span><input required value={rsvp.name} onChange={(e) => setRsvp({ ...rsvp, name: e.target.value })} placeholder="अपना नाम लिखें" autoComplete="name" /></label>
                  <label className="field-label">मोबाइल नंबर <span className="optional-label">वैकल्पिक</span><input type="tel" value={rsvp.phone} onChange={(e) => setRsvp({ ...rsvp, phone: e.target.value })} placeholder="+91 98765 43210" autoComplete="tel" /></label>
                  <fieldset className="attendance-field"><legend>क्या आप पधारेंगे?</legend><label className={`attendance-option ${rsvp.attendance === 'yes' ? 'selected' : ''}`}><input type="radio" name="attendance" value="yes" checked={rsvp.attendance === 'yes'} onChange={(e) => setRsvp({ ...rsvp, attendance: e.target.value })} /><span className="custom-radio" />सादर उपस्थित रहूँगा/रहूँगी</label><label className={`attendance-option ${rsvp.attendance === 'no' ? 'selected' : ''}`}><input type="radio" name="attendance" value="no" checked={rsvp.attendance === 'no'} onChange={(e) => setRsvp({ ...rsvp, attendance: e.target.value })} /><span className="custom-radio" />इस बार उपस्थित नहीं हो पाऊँगा/पाऊँगी</label></fieldset>
                  <label className="field-label">कितने अतिथि आएँगे? <select value={rsvp.guests} onChange={(e) => setRsvp({ ...rsvp, guests: e.target.value })} disabled={rsvp.attendance === 'no'}><option value="1">1 अतिथि</option><option value="2">2 अतिथि</option><option value="3">3 अतिथि</option><option value="4">4 अतिथि</option><option value="5+">5 या अधिक</option></select></label>
                  <label className="field-label">शुभकामना संदेश <span className="optional-label">वैकल्पिक</span><textarea rows="3" value={rsvp.message} onChange={(e) => setRsvp({ ...rsvp, message: e.target.value })} placeholder="नवयुगल के लिए अपना संदेश लिखें..." /></label>
                  <button type="submit" className="button button-maroon form-submit">उत्तर भेजें <Send size={16} /></button>
                  <p className="form-privacy">यह नमूना फॉर्म उत्तर को केवल इसी डिवाइस के ब्राउज़र में रखता है।</p>
                </form>
              )}
            </Reveal>
          </div>
        </section>

        <section className="closing-section section-pad">
          <Reveal>
            <div className="closing-mandala" aria-hidden="true"><span>शुभ</span></div>
            <p className="section-kicker">आपका आना, हमारा सौभाग्य</p>
            <h2>आपकी उपस्थिति से<br /><em>पूर्ण होगा यह उत्सव</em></h2>
            <p>प्रेम, परंपरा और आशीर्वाद के इस पावन अवसर पर<br className="desktop-break" /> आप सपरिवार सादर आमंत्रित हैं।</p>
            <div className="closing-names">{fullNames.bride} <span>✦</span> {fullNames.groom}</div>
            <button type="button" className="button button-outline" onClick={shareInvitation}><Share2 size={16} /> आमंत्रण आगे भेजें</button>
          </Reveal>
        </section>
      </main>

      <footer className="site-footer">
        <div className="footer-brand"><span className="brand-mark"><span>श्री</span><i /></span><span><strong>शुभ विवाह</strong><small>राजसी परंपरा · अनंत प्रेम</small></span></div>
        <p>मंगलमय हो यह पावन बंधन <span>✦</span></p>
        <div className="site-footer-links"><a href="/ganesh">श्री गणेश वंदना</a><a href="/events">सभी रस्में</a><a href="/story">हमारी कहानी</a><a href="/venue">विवाह स्थल</a><a href="/gallery">चित्रावली</a><a href="/rsvp">RSVP</a><a href="/admin">व्यवस्थापक</a></div>
        <button className="back-to-top" type="button" onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} aria-label="ऊपर जाएँ"><ArrowDown size={17} /></button>
      </footer>

      {introVisible && (
        <div className={`invitation-intro ${introLeaving ? 'intro-leaving' : ''}`} role="dialog" aria-modal="true" aria-label="विवाह आमंत्रण खोलें">
          <div className="intro-flower intro-flower-one">✿</div><div className="intro-flower intro-flower-two">✿</div>
          <p className="intro-blessing">॥ श्री गणेशाय नमः ॥</p>
          <div className="intro-garden-frame">
            <span className="intro-garden-aura" aria-hidden="true" />
            <img src={weddingData.ganeshGardenPhoto || '/images/ganesh-garden-hero.jpg'} alt="राजस्थानी पुष्प-वाटिका में विराजमान भगवान श्री गणेश जी" />
            <span className="intro-garden-caption">प्रथम पूज्य · मंगलमय शुभारंभ</span>
          </div>
          <p className="intro-first-invite">सर्वप्रथम विघ्नहर्ता श्री गणेश जी को<br />सादर प्रथम निमंत्रण</p>
          <h2>श्री गणेश जी के<br /><em>शुभ आशीर्वाद सहित</em></h2>
          <p>विघ्न विनाशक मंगलकर्ता के चरणों में<br />हमारे शुभ विवाह का सादर निमंत्रण</p>
          <button className="button button-gold intro-open-button" type="button" onClick={openInvitation}>आशीर्वाद सहित आमंत्रण खोलें <ArrowUpRight size={16} /></button>
          <span className="intro-bottom">राजसी राजस्थानी अंदाज़ में सजा एक निमंत्रण</span>
        </div>
      )}
      <Toast toast={toast} />
    </div>
  )
}


export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<WeddingHome />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/ganesh" element={<FixedInvitationPage fixedSlug="ganesh" />} />
        <Route path="/events" element={<FixedInvitationPage fixedSlug="events" />} />
        <Route path="/story" element={<FixedInvitationPage fixedSlug="story" />} />
        <Route path="/venue" element={<FixedInvitationPage fixedSlug="venue" />} />
        <Route path="/gallery" element={<FixedInvitationPage fixedSlug="gallery" />} />
        <Route path="/rsvp" element={<FixedInvitationPage fixedSlug="rsvp" />} />
        <Route path="/:slug" element={<CustomWeddingPage />} />
        <Route path="*" element={<CustomWeddingPage />} />
      </Routes>
    </BrowserRouter>
  )
}
